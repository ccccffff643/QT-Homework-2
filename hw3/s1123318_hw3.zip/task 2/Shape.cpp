#include "Shape.h"

double Shape::perimeter(){

    return 0.0;
}

double Shape::area(){

    return 0.0;
}
