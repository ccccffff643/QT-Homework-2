#pragma once

class Shape
{
private:
    /* data */
public:
    
    virtual double perimeter();
    virtual double area();
};
