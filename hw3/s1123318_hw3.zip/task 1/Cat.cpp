#include <iostream>
#include "Cat.h"

using std::cout;

void Cat::speak(){

    cout<< "MEOW!\n";
}
