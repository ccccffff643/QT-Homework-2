#include "Animal.h"

class Human: public Animal
{
private:
    /* data */
public:

    virtual void speak() override;
};
