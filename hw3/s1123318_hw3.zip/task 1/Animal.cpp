#include <iostream>
#include "Animal.h"

using std::cout;

void Animal::speak(){

    cout<< "*$&^)*_@*%*@)$^*()\n";    
}