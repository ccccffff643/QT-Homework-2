#include "Animal.h"

class Cow: public Animal
{
private:
    /* data */
public:

    virtual void speak() override;
};
