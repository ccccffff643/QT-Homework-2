#include "Animal.h"

class Dog: public Animal
{
private:
    /* data */
public:

    virtual void speak() override;
};
