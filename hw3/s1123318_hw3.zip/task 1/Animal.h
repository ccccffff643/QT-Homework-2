#pragma once

class Animal
{
private:
    /* data */
public:

    virtual void speak();
};
