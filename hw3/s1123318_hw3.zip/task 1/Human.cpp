#include <iostream>
#include "Human.h"

using std::cout;

void Human::speak(){

    cout<< "Hi!\n";
}