#include "Animal.h"

class Cat: public Animal
{
private:
    /* data */
public:

    virtual void speak() override;
};
