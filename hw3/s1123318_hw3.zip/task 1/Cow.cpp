#include <iostream>
#include "Cow.h"

using std::cout;

void Cow::speak(){

    cout<< "MOO!\n";
}