#include <iostream>
#include "Dog.h"

using std::cout;

void Dog::speak(){

    cout<< "RUFF!\n";
}
